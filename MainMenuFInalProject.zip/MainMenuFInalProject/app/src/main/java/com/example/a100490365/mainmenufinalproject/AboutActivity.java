package com.example.a100490365.mainmenufinalproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
/**
 * Created by 100490365 on 9/29/2017.
 */

public class AboutActivity extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);

    }

    public void Finish(View view){
        finish();
    }



}
