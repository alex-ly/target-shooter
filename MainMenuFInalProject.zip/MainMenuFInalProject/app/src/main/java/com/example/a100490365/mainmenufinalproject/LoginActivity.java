package com.example.a100490365.mainmenufinalproject;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

/**
 * Created by 100490365 on 9/29/2017.
 */

public class LoginActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }



    public void check(View v){
        String NAME = "Gayanath";
        EditText et=(EditText)findViewById(R.id.editText2);
        String user=et.getText().toString();
        Intent intent= new Intent();

        if(NAME.equals(user)){
            //Log.i("Lab3", R.string.success);
            intent.putExtra("MainMenuFinalProject", "Login success");

        }else{
            //Log.i("Lab3", @string/fail);
            intent.putExtra("MainMenuFinalProject", "Username not Recognized");
        }
        setResult(1, intent);
        finish();

        //Log.i("Lab3","Login success");
    }
}