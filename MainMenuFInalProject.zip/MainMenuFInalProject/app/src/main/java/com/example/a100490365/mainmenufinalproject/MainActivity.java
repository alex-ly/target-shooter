package com.example.a100490365.mainmenufinalproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    static final int Login_code = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void about(View source){
        Intent intent = new Intent(this,AboutActivity.class);
        startActivity(intent);
    }

    public void login(View source){
        Intent intent = new Intent(this,LoginActivity.class);
        startActivityForResult(intent,Login_code);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent result){
        super.onActivityResult(requestCode,resultCode,result);
        if (requestCode == Login_code ){
            String msg=result.getStringExtra("MainMenuFinalProject");
            Log.i("MainMenuFinalProject",msg);
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        }
    }

}
